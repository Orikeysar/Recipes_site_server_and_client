import React from "react";
import { createContext, useState, useEffect } from "react";
import SWAGGER_URL from "../../ApiComponent";

const IngredintContext = createContext();

export const IngredintProvider = ({ children }) => {
  

  const [allIngredients, setAllIngredients] = useState([]);

  useEffect(() => {
    getAllIngredients();
  }, []);

  const getAllIngredients = async (children) => {
    const allIngAdd = "/Ingredient";
    const IngredientApi = SWAGGER_URL + allIngAdd;
    const response = await fetch(IngredientApi)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setAllIngredients(data);
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  const AddNewIngredient = (newIng) => {
    const allIngAdd = "/Ingredient";
    const IngredientApi = SWAGGER_URL + allIngAdd;
    // Send data to the backend via POST
    fetch(IngredientApi, {
      method: "POST",
      body: JSON.stringify(newIng),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        window.location.reload();
        // Handle data
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  return (
    <IngredintContext.Provider
      value={{
        allIngredients,
        AddNewIngredient,
      }}
    >
      {children}
    </IngredintContext.Provider>
  );
};

export default IngredintContext;
