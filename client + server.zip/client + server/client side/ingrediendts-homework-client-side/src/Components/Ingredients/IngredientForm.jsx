import { useState, useContext } from "react";
import MakeButton from "../Button";
import IngredintContext from "./IngredintProvider.jsx";
import Ingredint from "./Ingredint";
import IngredientList from "./IngredientList";


function IngredientForm() {
  const [name, SetName] = useState("");
  const [calories, SetCalories] = useState("");
  const [image, SetImg] = useState("");
  const { AddNewIngredient } = useContext(IngredintContext);

  const HandleSetBtn = (e) => {
    e.preventDefault();
    const newIng = { name, calories, image };
    AddNewIngredient(newIng);
    SetName("");
    SetCalories("");
    SetImg("");
    window.location.reload();
  };
  const HandleChangeName = (e) => {
    SetName(e.target.value);
  };
  const HandleChangeCalories = (e) => {
    SetCalories(e.target.value);
  };
  const HandleChangeImg = (e) => {
    SetImg(e.target.value);
  };
  return (
    <div className="card">
      <form onSubmit={HandleSetBtn}>
        <h2>Enter new Ingridient:</h2>
        <p className="text-xl">
          Name:
          <input
            value={name}
            type="name"
            placeholder="Write a name"
            id="IngNameText"
            onChange={HandleChangeName}
            required={true}
            className="bg-slate-100 text-xl ml-4  border-teal-600 border"
          />
        </p>
        <p className="text-xl">
          calories :
          <input
            value={calories}
            type="calories"
            placeholder="Write the calories"
            id="IngCaloriesTxt"
            onChange={HandleChangeCalories}
            required={true}
            className="bg-slate-100 text-xl ml-4  border-teal-600 border"
          />
        </p>
        <p className="text-xl">
          imageURL:
          <input
            value={image}
            type="imageURL"
            placeholder="Write a imageURL"
            id="IngImageURLTxt"
            onChange={HandleChangeImg}
            required={true}
            className="bg-slate-100 text-xl ml-4 border-teal-600 border"
          />
        </p>
        <MakeButton type="submit" onClick={HandleSetBtn}>
          send
        </MakeButton>
      </form>
    </div>
  );
}

export default IngredientForm;
