import React from "react";
import PropTypes from "prop-types";
import { useContext } from "react";
import Ingredint from "./Ingredint";
import IngredintContext from "./IngredintProvider";

function IngredientList() {
  const { allIngredients } = useContext(IngredintContext);

  // output if we dont have any ing
  if (!allIngredients || allIngredients.length === 0) {
    return <p>Do not have a ingredient yet</p>;
  }
  return (
    <div className="ing-list grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-1 gap-8 mb-4">
      {/* MAP FOR GET EVRY ING FROM LIST      */}
      {allIngredients.map((item) => (
        <div key={item.id}>
          <Ingredint key={item.id} item={item} />
        </div>
      ))}
    </div>
  );
}

export default IngredientList;
