import React from "react";
import { createContext } from "react";
import { CardImg } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
function Ingredint({ item }) {
  return (
    <Card >
<Card.Body>
       
  <div className="text-xl underline"> Name - {item.name}</div>
      
      <div className="cal text-xl"> Calories - {item.calories}</div>
     </Card.Body> 
     
     <Card.Img variant="top text-xl" src={item.image} className='object-fill max-h-96 max-w-96  w-full items-center' />
      
      
    </Card>
  );
}

export default Ingredint;
