import React from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useState } from "react";

import { useContext } from "react";
import Ingredint from "./Ingredint";
import IngredintContext from "./IngredintProvider";
import MakeButton from '../Button';
import DishContext from '../dishes/DishProvider';
function AllIngredientModal({addNewIngToDish}) {
    const [show, setShow] = useState(false);
   
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const { allIngredients } = useContext(IngredintContext);
 
// const HandleAddIngToDishBtn=(e)=>{

//     addingredient(e.value.target)
//    //TO ADD HERE CONNECTION TO FUNCTION IN PROIVIDER
   
// }

  // output if we dont have any ing
  if (!allIngredients || allIngredients.length === 0) {
    return <p>Do not have a ingredient yet</p>;}

  return (
    <>
      <Button variant="primary" onClick={handleShow} className='text-sm m-2 p-2 w-auto'>
        Choose Ingredients:
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
        className=' fixed top-5  m-2 p-5 bg-white h-auto '
        
       
      >
        <Modal.Header closeButton>
          <Modal.Title className='text-black'>Choose All Ingredients in thid dish:</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{
      maxHeight: 'calc(100vh - 210px)',
      overflowY: 'auto'
     }} className="ing-list grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 gap-8 mb-4">
             
      {/* MAP FOR GET EVRY ING FROM LIST      */}
      {allIngredients.map((item) => (
        <div key={item.id +'Dish'}>
          <Ingredint key={item.id+'Dish'} item={item} />
          <Button key={item.id} variant="primary" type="submit" onClick={()=>addNewIngToDish(item)} className='btn '>
        Add Me
      </Button>
        </div>
      ))}
  

        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose} className='mt-3'>
            Close Modal
          </Button>
         
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default AllIngredientModal