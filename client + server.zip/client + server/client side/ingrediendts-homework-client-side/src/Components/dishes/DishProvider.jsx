import React from "react";
import { createContext, useState,useEffect } from "react";
import SWAGGER_URL from "../../ApiComponent";

const DishContext = createContext();

export const DishProvider=({children}) => {



 
  const allRecipeAdd = '/Recipe';
  
  const [allDishes, setAllDishes] = useState([]);
  const [allDishToDone, setAllDishToDone] = useState([]);
  const [dishID, setDishID] = useState();
  const [ingID, setIngID] = useState();
 
  const [newIngInDish, setNewIngInDish] = useState();


   useEffect(()=>{
    getAllRecpies();
  
  
  
   },[])
  


  const getAllRecpies = async (children) => {
    const RecpieApi = SWAGGER_URL+allRecipeAdd;
    const response = await fetch(RecpieApi)
    .then(response => response.json())
    .then((data) => {
      console.log(data);
      setAllDishes(data);
   })
   .catch((err) => {
      console.log(err.message);
   });
  
  }

//בעיה לוגית ... לא ניתן להכניס מרכיבים למנה לפני שהמנה מוכנה
//func to add new dish
  const AddNewDish = (newDish,ingredientInDish) => {
    const RecpieApi = SWAGGER_URL+allRecipeAdd;
    fetch(RecpieApi, {
      method: 'POST',
      body: JSON.stringify(newDish),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    }) .then((response) => response.json())
    .then((data) => {
       console.log(data);
       setIngInDish(ingredientInDish, data)
       // Handle data
    })
    .catch((err) => {
       console.log(err.message);
    });
    
    
  };

  const setIngInDish=(ingredientInDish, dishId)=>{

    ingredientInDish.map((item) => {
      const INGinDishApi = `/Recipe/ingId/${item.id}/resId/${dishId}`
      const IngInDishApi = SWAGGER_URL+INGinDishApi;

    
 
     fetch(IngInDishApi, {
      method: 'POST',
      body: JSON.stringify({
        ingId:item.id,
      resId:dishId
      }),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
      
    }) .then((response) => response.json())
    .then((data) => {
       console.log(data);
       // Handle data
    })
    .catch((err) => {
       console.log(err.message);
    })

  })}

  //func to add new dish to done dish array
  const AddNewDishToDone = (newDish) => {
if (newDish.id === null) {
   newDish.id = allDishToDone.length;
}
  
    setAllDishToDone([newDish, ...allDishToDone]);
  };

  //delete dish
  const DeleteDishFromAllDishes =(id)=>{

    setAllDishes(allDishes.filter((item) => item.id !== id))

  }

  //delete dish from done dish
  const DeleteDishFromAllDishesDone =(id)=>{

    setAllDishToDone(allDishToDone.filter((item) => item.id !== id))

  }

  const AddNewDishToPreper=(item)=>{

    setAllDishes([item, ...allDishes]);
    
  }
  return (
    <DishContext.Provider
      value={{
        allDishToDone,
        allDishes,
        AddNewDish,
        AddNewDishToDone,
        DeleteDishFromAllDishes,
        DeleteDishFromAllDishesDone,
        AddNewDishToPreper,
      }}
    >
      {children}
    </DishContext.Provider>
  )
}

export default DishContext;
