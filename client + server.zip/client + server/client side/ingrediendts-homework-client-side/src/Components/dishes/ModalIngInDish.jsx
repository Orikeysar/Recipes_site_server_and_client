import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useState, useContext, useEffect } from "react";
import DishContext from "../dishes/DishProvider";
import Ingredint from "../Ingredients/Ingredint";
import IngredintContext from "../Ingredients/IngredintProvider";

function ModalIngInDish({ ingredientInDish }) {
  const { allIngredients } = useContext(IngredintContext);
  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false); 
    window.location.reload()
  };
  const handleShow = () => setShow(true);

  const ingTempArray = ingredientInDish.map((id) =>
    allIngredients.find((obj) => {
      return obj.id == id;
    })
  );

  // output if we dont have any ing
  if (ingTempArray.length === 0) {
    return <p>Do not have a ingredient in this dish</p>;
  }

  return (
    <>
      <Button
        variant="primary"
        onClick={handleShow}
        className="text-sm m-2 p-2"
       
      >
        Ingredients:
      </Button>

      <Modal
        show={show}
        onExit={handleClose}
        onHide={handleClose}
        onShow={handleShow}
        backdrop="static"
        keyboard={false}
        className=" fixed top-5  m-2 p-5 bg-white h-auto "
      >
        <Modal.Header closeButton>
          <Modal.Title className="text-black">
            Choose All Ingredients in thid dish:
          </Modal.Title>
        </Modal.Header>
        <Modal.Body
          className=" ing-list grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 gap-8 mb-4"
          style={{
            maxHeight: "calc(100vh - 210px)",
            overflowY: "auto",
          }}
        >
       
            {/* MAP FOR GET EVRY ING FROM LIST      */}

            {ingTempArray.map((item) => (
              <div key={item.id + "InDish"}>
                <Ingredint key={item.id + "InDish"} item={item} />
              </div>
            ))}
            
          
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose} className="mt-3">
            Close Modal
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalIngInDish;
