import React from 'react'
import { useState, useContext } from "react";
import MakeButton from '../Button';
import AllIngredientModal from '../Ingredients/AllIngredientModal';
import DishContext from './DishProvider';
import uuid from 'react-uuid';


function DishForm() {
  
  const [ingredientInDish, SetIngredientInDish] = useState([]);
    const [name, SetName] = useState("");
    const [calories, SetCalories] = useState("");
    const [time, SetTime] = useState("");
    const [cookingMethod, SetCookingMethod] = useState("");
    const [image, SetImg] = useState("");
    const { AddNewDish } = useContext(DishContext);
    const [isPreper, SetisPreper] = useState("");
    
    const HandleDishSetBtn = (e) => {
        e.preventDefault();
        SetisPreper(false)

        const newDish = { name,image,cookingMethod, time };
        AddNewDish(newDish,ingredientInDish);
        SetName("");
        SetCalories("");
        SetImg("");
        SetTime("");
        SetCookingMethod("");
        SetIngredientInDish([]);
        window.location.reload();
      };
    
      const HandleChangeDishName = (e) => {
        SetName(e.target.value);
      };
      const HandleChangeDishCalories = (e) => {
        SetCalories(e.target.value);
      };
      const HandleChangeDishImg = (e) => {
        SetImg(e.target.value);
      };
      const HandleChangeDishTime = (e) => {
        SetTime(e.target.value);
      };
      const HandleChangeDishCookingMethod = (e) => {
        SetCookingMethod(e.target.value);
      };

//add new ING in this dish
const addNewIngToDish = (newIng)=>{
  
  SetIngredientInDish([newIng, ...ingredientInDish])
alert( newIng.name + " was added")


}

  return (
    <div className="card">
    <form onSubmit={HandleDishSetBtn}> 
    <h2>Enter new Dish:</h2>
      <div className='grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-1 gap-8 mb-4 items-center text-center'>
     
      <p className='text-xl ml-24'>
        Name: 
        <input
          value={name}
          type="name"
          placeholder="Insert Dish name"
          id="IngNameText"
          onChange={HandleChangeDishName}
          className=' bg-slate-100 text-xl ml-4 border-teal-600 border'
          required={true}
        />
      </p>
      <p className='text-xl ml-24'>
        calories :
        <input
          value={calories}
          type="calories"
          placeholder="Insert calories"
          id="IngCaloriesTxt"
          onChange={HandleChangeDishCalories}
          className=' bg-slate-100 text-xl ml-4 border-teal-600 border'
          required={true}
        />
      </p>
      <p className='text-xl'>
        Coocking Time:
        <input
         id="appt"
          value={time}
          type="number"
          placeholder="Insert the time in minutes"
          className=' bg-slate-100 text-xl ml-4 border-teal-600 border'
          onChange={HandleChangeDishTime}
          required={true}
        />
      </p>
      <p className='text-xl'>
        Coocking Method:
        <input
          value={cookingMethod}
          type="cookingMethod"
          placeholder="Write coocking Method"
          id="DishCookingMethodText"
          onChange={HandleChangeDishCookingMethod}
          className='bg-slate-100 text-xl ml-4 border-teal-600 border'
          required='true'
        />
      </p></div>
      <p className='text-xl mt-4 mb-4 mr-12'>
        imageURL:
        <input
          value={image}
          type="imageURL"
          placeholder="Insert a imageURL"
          id="IngImageURLTxt"
          onChange={HandleChangeDishImg}
          className='bg-slate-100 text-xl ml-4  border-teal-600 border'
          required={true}
        />
      </p>

<div className='modal'>
  <AllIngredientModal addNewIngToDish={addNewIngToDish}/>
</div>


      <MakeButton className='' type="submit" onClick={HandleDishSetBtn}>
        send
      </MakeButton>
    </form>
  </div>
  )
}

export default DishForm
