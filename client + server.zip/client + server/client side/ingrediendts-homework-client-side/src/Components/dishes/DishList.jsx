import React from 'react'
import {useState, useContext } from "react";
import Dish from './Dish';
import DishContext from './DishProvider';

function DishList() {


    const { allDishes,allDishToDone, } = useContext(DishContext);
    const { ingredientInDish,setIngredientInDish } = useState([




    ])
  // output if we dont have any Dish
    if ((allDishToDone.length === 0  && allDishes.length === 0 )||(!allDishToDone && !allDishes )) {
        return <p>Do not have a Dishes yet</p>;
      }

  return (
    
    <div >
    {/* MAP FOR GET EVRY DISH FROM LIST      */}
    <h2 className="text-xl">All Ready Dishes To preper: ({allDishes.length})</h2>
    <div className="dish-list grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-1 gap-8 mb-4">
    {allDishes.map((item) => (
      <div key={item.id}>
        <Dish key={item.id} ingredientInDish={ ingredientInDish} disable="false" item={item} />
      </div>
    ))}
 </div>
    {/* MAP FOR GET EVRY DISH FROM LIST      */}
    <h2 className="text-xl">All Ready Dishes To Eat: ({ allDishToDone.length})</h2>
    <div className="dish-list grid grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-1 gap-8 mb-4">
    {allDishToDone.map((item) => (
      <div key={item.id}>
        <Dish key={item.id} ingredientInDish={ingredientInDish} disable="true" item={item} />
      </div>
    ))}</div>
  </div>
  )
}

export default DishList
