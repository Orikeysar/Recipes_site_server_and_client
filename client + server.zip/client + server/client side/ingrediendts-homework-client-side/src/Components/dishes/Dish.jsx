import React from "react";
import MakeButton from "../Button";
import { useContext } from "react";
import DishContext from "./DishProvider";
import { useState,useEffect } from "react";
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import ModalIngInDish from "./ModalIngInDish";

function Dish({item, disable }) {
  
  const SWAGGER_URL = 'https://localhost:7218/api';
  const { AddNewDishToDone,DeleteDishFromAllDishes, AddNewDish,DeleteDishFromAllDishesDone,AddNewDishToPreper } = useContext(DishContext);
  const [ingredientInDish, setIngredientInDish] = useState([]);
  const [show, setShow] = useState(false);

  const handleShow = () => setShow(true);


  const [isPreper,SetPreper] = useState("");
  useEffect(()=>{
    getAllingredientInDish();
  
  
  
   },[])
//Fetch All ING in this Dish
  

const getAllingredientInDish = async () => {
    const IngInDishApi = `/Recipe/resId/${item.id}`
    const RecpieApi = SWAGGER_URL+IngInDishApi;
    const response = await fetch(RecpieApi)
    .then(response => response.json())
    .then((data) => {
      console.log(data);
      setIngredientInDish(data);
   })
   .catch((err) => {
      console.log(err.message);
   });
  
  }








  const HandleDishSetBtnDone = (e) => {
    SetPreper(true)
    item.isPreper = true;
    e.preventDefault();
    DeleteDishFromAllDishes(item.id);
    AddNewDishToDone(item);
  };
  const HandleDishSetBtnEat = (e) => {
    SetPreper(true)
    item.isPreper = false;
    e.preventDefault();
    DeleteDishFromAllDishesDone(item.id);
    AddNewDishToPreper(item);
  };
  if(item.isPreper){
    return (
      <form onSubmit={HandleDishSetBtnEat}>
        <Card >


<Card.Title className="">{item.name}</Card.Title>
  <Card.Body>
  <div className="text">Dish Time: {item.time}</div>
  {/* <div className="text">Dish Calories: {item.calories}</div> */}
  <div className="text max-w-full">
    Dish Cooking Method: {item.cookingMethod}
  </div> 
  </Card.Body>
{/* INGRIDENTS MODAL */} 
        <ModalIngInDish ingredientInDish={ingredientInDish}/>

          
          <div className="image-display items-center">
            <img className="object-fill max-h-96 min-h-96  w-full items-center" alt="" src={item.image}></img>
          </div>
          <MakeButton
            type="submit"
            disable={disable}
            onClick={() => {
              HandleDishSetBtnEat(item);
            }}
          >
            Eat
          </MakeButton>
        
        </Card>
      </form>
    );

  }else{return (
    <form  onSubmit={HandleDishSetBtnDone}>
      <Card >


      <Card.Title className="text-2xl underline">{item.name}</Card.Title>
        <Card.Body>
        <div className="text-xl">Dish Time - {item.time}</div>
    
        <div className="text-xl max-w-full">
         Cooking Method - {item.cookingMethod}
        </div> 
        <ModalIngInDish ingredientInDish={ingredientInDish}/>
        </Card.Body>
        
        <div className="image-display  w-full ">
          <img className="object-fill max-h-96 min-h-96  w-full" alt="" src={item.image}></img>
        </div>
        <MakeButton
          type="submit"
          disable={disable}
          onClick={() => {
            HandleDishSetBtnDone(item);
            
          }}
          
        >
          Prepre Dish
        </MakeButton>
     </Card>
    </form>
  );}

  
}

export default Dish;
