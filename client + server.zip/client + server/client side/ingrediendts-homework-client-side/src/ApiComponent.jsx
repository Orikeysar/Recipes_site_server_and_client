
const SWAGGER_URL = 'https://localhost:7218/api';
  


export default SWAGGER_URL
